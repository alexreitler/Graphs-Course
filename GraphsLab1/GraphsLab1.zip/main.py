from ui import *

repo = Graph()

user_interface = UI(repo)

user_interface.console()
